using System;

namespace BunnyEscape.Core.Interfaces
{
    public interface IGameCharacter
    {
        void UpdateImagePath();
    }
}