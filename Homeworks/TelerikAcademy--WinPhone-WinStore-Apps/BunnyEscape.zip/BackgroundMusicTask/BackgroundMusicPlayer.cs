﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Windows.ApplicationModel.Background;

namespace BackgroundTasks
{
    public sealed class BackgroundMusicPlayer : IBackgroundTask
    {

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }
    }
}
