﻿using System;

class QuickSort
{
    static void Main(string[] args)
    {
    }
}