﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _11___Delete_words_starting_with
{

    class Program
    {
        
        static void Main(string[] args)
        {
            
        }
    }
}
